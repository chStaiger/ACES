/**
 * A framework for module searching.
 */
package modlab;
