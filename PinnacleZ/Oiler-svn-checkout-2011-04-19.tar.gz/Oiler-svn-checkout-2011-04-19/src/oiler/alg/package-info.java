/**
 * Algorithms that operate on graphs.
 */
package oiler.alg;
