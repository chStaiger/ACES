/**
 * A high-performance graph library.
 */
package oiler;
