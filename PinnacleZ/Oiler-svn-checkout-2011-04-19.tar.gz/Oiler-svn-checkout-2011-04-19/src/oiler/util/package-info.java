/**
 * High-performance data structures and utilities that operate on
 * <code>int</code>s.
 */
package oiler.util;
