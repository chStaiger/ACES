/**
 * Utility classes for module searching.
 */
package modlab.util;
